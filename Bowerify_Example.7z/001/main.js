var math1 = require('./myModule1');
var math2 = require('./myModule2');

console.log(math1().add(1,5));
console.log(math2().add(5,6));

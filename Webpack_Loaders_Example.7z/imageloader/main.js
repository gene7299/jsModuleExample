var img1 = document.createElement("img");
img1.src = require("./div-bg1.jpg");
document.body.appendChild(img1);
var img2 = document.createElement("img");
img2.src = require("./bg.jpg");
document.body.appendChild(img2);

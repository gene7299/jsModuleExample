function apply(){
  require('./div2_border.css');
  require('./div3.css');
}
module.export = apply();

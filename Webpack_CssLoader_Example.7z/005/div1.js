function apply(){
  require('./div1_border.css');
  require('./div3.css');
}
module.export = apply();

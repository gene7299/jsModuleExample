function apply(){
  require('./div1.css');
}
module.export = apply();

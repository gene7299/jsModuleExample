//global.$ = require('jquery');
var math1 = require('./myModule1');
console.log(math1.add(1,5));

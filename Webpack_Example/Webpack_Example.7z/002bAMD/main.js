global.$ = require('jquery');

require(['./myModule1'], function (math1){
    console.log(math1.add(1,5));
  });

require(['./myModule2'], function (math2){
　　　 console.log(math2.add(5,6));
　　});

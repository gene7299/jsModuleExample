function myMath2() {

  var add = function (x,y){
            $('#result2').html("result2="+(x+y));
  　　　　　　return x+y;
  　　　　};
    return {
            add: add
          };
}
function myMath3() {

  var add = function (x,y){
            $('#result3').html("result3="+(x+y));
  　　　　　　return x+y;
  　　　　};
    return {
            add: add
          };
}

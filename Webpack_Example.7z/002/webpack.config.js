module.exports = {
    entry: {
      app: "./main.js"
    },
    output: {
        filename: "bundle.js"
    }
}

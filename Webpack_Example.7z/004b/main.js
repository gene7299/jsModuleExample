var myMath1 = require('./myModule1');
console.log(myMath1().add(1,5));

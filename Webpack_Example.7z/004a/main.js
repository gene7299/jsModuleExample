var myMath1 = require("exports?myMath1!./myModule1.js");
console.log(myMath1().add(1,5));

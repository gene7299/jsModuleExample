webpackJsonp([0],[
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	//global.$ = require('jquery');

	__webpack_require__.e/* nsure */(1, function(require){
	  var math1 = __webpack_require__(1);
	  console.log(math1.add(1,5));
	});

	__webpack_require__.e/* require */(2, function(__webpack_require__) { var __WEBPACK_AMD_REQUIRE_ARRAY__ = [__webpack_require__(3)]; (function (math2){
	　　　 console.log(math2.add(5,6));
	　　}.apply(null, __WEBPACK_AMD_REQUIRE_ARRAY__));});


/***/ }
]);